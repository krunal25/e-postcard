export enum postcardEnum {
    Postcard_Created = 'Postcard created successfully',
    Postcard_Not_Eist = 'Postcard does not exist',
    Postcard_Found = 'Postcard Found',
  }
  